import { Switch, Route, Router as WouterRouter, Redirect, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import LoginPage from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import WorkersPage from "@/pages/Workers";
import UsersPage from "@/pages/Users";
import CategoriesPage from "@/pages/Categories";
import CitiesPage from "@/pages/Cities";
import ReviewsPage from "@/pages/Reviews";
import AdsPage from "@/pages/Advertisements";
import MessagesPage from "@/pages/Messages";
import SettingsPage from "@/pages/Settings";
import AppointmentsPage from "@/pages/Appointments";
import SeedPage from "@/pages/Seed";

const queryClient = new QueryClient();
const base = import.meta.env.BASE_URL.replace(/\/$/, "");

function AppRoutes() {
  const { admin, loading } = useAuth();
  const [location] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-primary flex items-center justify-center shadow">
            <span className="text-white text-sm font-bold">KM</span>
          </div>
          <div className="h-5 w-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  if (!admin && location !== "/login") {
    return <Redirect to="/login" />;
  }

  if (admin && location === "/login") {
    return <Redirect to="/" />;
  }

  return (
    <Switch>
      <Route path="/login" component={LoginPage} />
      <Route path="/" component={Dashboard} />
      <Route path="/workers" component={WorkersPage} />
      <Route path="/users" component={UsersPage} />
      <Route path="/categories" component={CategoriesPage} />
      <Route path="/cities" component={CitiesPage} />
      <Route path="/reviews" component={ReviewsPage} />
      <Route path="/ads" component={AdsPage} />
      <Route path="/appointments" component={AppointmentsPage} />
      <Route path="/messages" component={MessagesPage} />
      <Route path="/settings" component={SettingsPage} />
      <Route path="/seed" component={SeedPage} />
      <Route><Redirect to="/" /></Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={base}>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;
